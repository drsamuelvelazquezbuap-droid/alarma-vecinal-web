-- EJECUTAR EN EL PROYECTO ORIGINAL: etksfzadgjdpvwwaovmx
-- Este script crea tablas propias para esta nueva web. No modifica tablas anteriores.
-- NO habilita ninguna sirena física.
create table if not exists public.profiles (
 id uuid primary key references auth.users(id) on delete cascade,
 name text not null check(length(name) between 1 and 100),
 role text not null default 'vecino' check(role in ('vecino','representante')),
 enabled boolean not null default false,
 created_at timestamptz not null default now()
);
create table if not exists public.alarm_state (
 id integer primary key check(id=1),
 active boolean not null default false,
 activated_at timestamptz,
 expires_at timestamptz,
 updated_at timestamptz not null default now()
);
insert into public.alarm_state(id) values(1) on conflict(id) do nothing;
create table if not exists public.alarm_events (
 id bigint generated always as identity primary key,
 actor_id uuid references auth.users(id) on delete set null,
 actor_name text not null,
 action text not null check(action in ('activar','desactivar')),
 created_at timestamptz not null default now()
);
create index if not exists alarm_events_created_at_idx on public.alarm_events(created_at desc);
alter table public.profiles enable row level security;
alter table public.alarm_state enable row level security;
alter table public.alarm_events enable row level security;
-- Sin políticas directas: únicamente el backend con service_role accede a las tablas.
-- El backend valida cada JWT y verifica enabled=true.
create or replace function public.demo_alarm_action(p_actor uuid,p_action text)
returns jsonb
language plpgsql
security invoker
set search_path = public
as $$
declare v_name text; v_active boolean; v_exp timestamptz;
begin
 if p_action not in ('activar','desactivar') then raise exception 'Acción inválida'; end if;
 select name into v_name from public.profiles where id=p_actor and enabled=true for share;
 if v_name is null then raise exception 'Usuario no autorizado'; end if;
 select active,expires_at into v_active,v_exp from public.alarm_state where id=1 for update;
 if p_action='activar' and v_active and v_exp>now() then raise exception 'La simulación ya está activa'; end if;
 update public.alarm_state set active=(p_action='activar'),
 activated_at=case when p_action='activar' then now() else null end,
 expires_at=case when p_action='activar' then now()+interval '60 seconds' else null end,
 updated_at=now() where id=1;
 insert into public.alarm_events(actor_id,actor_name,action) values(p_actor,v_name,p_action);
 return (select to_jsonb(s) from public.alarm_state s where id=1);
end;$$;
revoke all on function public.demo_alarm_action(uuid,text) from public,anon,authenticated;
grant execute on function public.demo_alarm_action(uuid,text) to service_role;
