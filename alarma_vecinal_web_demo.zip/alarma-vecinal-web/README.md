# Alarma Vecinal 9 Oriente — versión de pruebas

Aplicación web compatible con iPhone, Android y navegadores modernos. Se puede añadir a la pantalla de inicio. **NO controla una sirena física** y **NO debe utilizarse como sistema de emergencia**.

## Qué incluye
- Inicio de sesión real con Supabase Auth (correo y contraseña).
- Validación de identidad y permisos en el servidor; los usuarios no pueden elegir su rol.
- Simulación de activar/desactivar, historial persistente, expiración lógica a los 60 segundos.
- Interfaz responsive en español y manifest PWA.
- Protección de tablas con RLS y rutas privadas.

## Qué NO incluye todavía
- Conexión real con Tuya/Smart Life ni apagado físico automático.
- Notificaciones push/SMS/WhatsApp a los cinco representantes.
- Panel visual de alta de usuarios; el comité los da de alta desde Supabase.
- Un mecanismo redundante de seguridad independiente del servidor para apagar la sirena.

## Configuración, paso a paso
1. **No borres tu proyecto anterior.** Crea un proyecto nuevo en Vercel importando este código desde GitHub (descomprime el ZIP y súbelo a un repositorio privado). No conectes la integración Supabase que crea un proyecto nuevo.
2. En Supabase abre el proyecto original `Alarma vecinal` (ref `etksfzadgjdpvwwaovmx`). Ejecuta `supabase/schema.sql` en SQL Editor **después de revisar las tablas que creará**. Este esquema no modifica las tablas antiguas.
3. En Supabase → Authentication → Users, crea cada cuenta manualmente y asigna contraseña temporal; establece la política de recuperación de contraseña. **Desactiva el registro público** si solo el comité puede dar acceso.
4. En Table Editor → `profiles`, crea un registro por cada usuario, con `id` igual al UUID del usuario de Auth, nombre, rol `vecino` o `representante`, y `enabled=true`. No asignes roles de representante sin verificación del comité.
5. En Vercel → proyecto NUEVO → Settings → Environment Variables, crea:
   - `NEXT_PUBLIC_SUPABASE_URL` = `https://etksfzadgjdpvwwaovmx.supabase.co`
   - `NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY` = clave publicable (`sb_publishable_...`) del proyecto original
   - `SUPABASE_SERVICE_ROLE_KEY` = clave `service_role` **solo en variables de servidor**, sin prefijo `NEXT_PUBLIC_`; jamás la pegues en chats, GitHub ni frontend
   - `ALARM_MODE` = `demo` (la aplicación permanece demo independientemente de esta variable)
   Configura Production y Preview según necesidad y vuelve a desplegar.
6. Abre la URL de Vercel e inicia sesión con un usuario habilitado. Prueba solo la **simulación**, nunca con la sirena conectada.

## Seguridad y limitaciones
- La API verifica el token Supabase Auth con `auth.getUser()` en cada solicitud y comprueba `profiles.enabled`.
- La clave de servidor permanece solo en el backend; la clave publicable puede estar en el navegador.
- Las tablas no tienen políticas de acceso directo de usuarios. El backend realiza las consultas usando una credencial de servidor.
- La expiración a 60 s es **lógica**, calculada al consultar el estado: no corta electricidad y no sirve como mecanismo de seguridad de una sirena real.
- Para operación real: diseñar controlador Tuya con credenciales exclusivamente en backend, permisos por acción, rate limiting, alertas a comité, apagado físico con temporizador independiente/failsafe, auditoría y pruebas controladas.
- Si hay error de configuración, la página muestra error; no se conecta a un proyecto Supabase alternativo.

## Desarrollo local
`npm install` y `npm run dev` con variables de `.env.example` copiadas a `.env.local` y completadas localmente. Nunca subas `.env.local`.
