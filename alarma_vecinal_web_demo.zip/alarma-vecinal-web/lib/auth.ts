import { NextRequest, NextResponse } from 'next/server';
import { serverAdmin } from './supabase';
export async function requireUser(req:NextRequest){
 const match=/^Bearer (.+)$/i.exec(req.headers.get('authorization')||'');
 if(!match)return {error:NextResponse.json({error:'Inicia sesión'},{status:401})};
 const admin=serverAdmin();const {data:{user},error}=await admin.auth.getUser(match[1]);
 if(error||!user)return {error:NextResponse.json({error:'Sesión inválida'},{status:401})};
 const {data:profile,error:pe}=await admin.from('profiles').select('id,name,role,enabled').eq('id',user.id).single();
 if(pe||!profile?.enabled)return {error:NextResponse.json({error:'Acceso no autorizado'},{status:403})};
 return {admin,profile};
}
