import { createClient } from '@supabase/supabase-js';
const EXPECTED='etksfzadgjdpvwwaovmx';
function url(){const u=process.env.NEXT_PUBLIC_SUPABASE_URL;if(!u || new URL(u).hostname!==`${EXPECTED}.supabase.co`)throw Error('La URL no pertenece al Supabase original');return u}
export function browserClient(){const key=process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY;if(!key)throw Error('Falta la clave publicable de Supabase');return createClient(url(),key,{auth:{persistSession:true,autoRefreshToken:true}})}
export function serverAdmin(){const key=process.env.SUPABASE_SERVICE_ROLE_KEY;if(!key)throw Error('Falta la clave de servidor de Supabase');return createClient(url(),key,{auth:{persistSession:false,autoRefreshToken:false}})}
