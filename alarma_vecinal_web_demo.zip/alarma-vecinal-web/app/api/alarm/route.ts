import { NextRequest, NextResponse } from 'next/server';
import { requireUser } from '../../../lib/auth';
export const dynamic='force-dynamic';
export async function GET(req:NextRequest){
 try{const ctx=await requireUser(req);if(ctx.error)return ctx.error;
 const {data:state,error:e}=await ctx.admin!.from('alarm_state').select('active,activated_at,expires_at,updated_at').eq('id',1).single();
 if(e)throw e;
 const {data:history,error:h}=await ctx.admin!.from('alarm_events').select('id,action,actor_name,created_at').order('created_at',{ascending:false}).limit(30);
 if(h)throw h;
 return NextResponse.json({state,history,role:ctx.profile!.role,mode:'demo'},{headers:{'Cache-Control':'no-store'}})
 }catch{return NextResponse.json({error:'No se pudo consultar el estado'},{status:500})}}
export async function POST(req:NextRequest){
 try{const ctx=await requireUser(req);if(ctx.error)return ctx.error;
 const body=await req.json().catch(()=>null);
 if(!body||!['activar','desactivar'].includes(body.action))return NextResponse.json({error:'Acción inválida'},{status:400});
 // Esta versión no contiene ninguna integración de control físico con Tuya.
 const {data,error}=await ctx.admin!.rpc('demo_alarm_action',{p_actor:ctx.profile!.id,p_action:body.action});
 if(error)return NextResponse.json({error:'No se pudo registrar la acción'},{status:400});
 return NextResponse.json({ok:true,state:data,mode:'demo'},{headers:{'Cache-Control':'no-store'}})
 }catch{return NextResponse.json({error:'Error al procesar solicitud'},{status:500})}}
