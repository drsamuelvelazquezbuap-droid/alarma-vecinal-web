import { NextResponse } from 'next/server';
export async function GET(){return NextResponse.json({status:'ok',mode:'demo',physicalSirenEnabled:false},{headers:{'Cache-Control':'no-store'}})}
