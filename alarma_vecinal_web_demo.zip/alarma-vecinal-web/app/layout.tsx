import type { Metadata, Viewport } from 'next';
import './style.css';
export const metadata: Metadata = { title:'Alarma Vecinal 9 Oriente', description:'Sistema vecinal de alertas', manifest:'/manifest.webmanifest', appleWebApp:{capable:true,title:'Alarma Vecinal',statusBarStyle:'black-translucent'} };
export const viewport: Viewport = {width:'device-width',initialScale:1,themeColor:'#101827'};
export default function RootLayout({children}:{children:React.ReactNode}) {return <html lang="es"><body>{children}</body></html>}
